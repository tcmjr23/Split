import java.util.Arrays;

public class Split {
	public static void main(String[] args) {
		
// Your task Part 0
//String.split();
//It's a method that acts on a string, <StringName>.split(<sp>);
//Where sp is the string where the string splits
//And it returns an array
		String[] ex1 = "I like apples!".split(" ");
		System.out.println(Arrays.toString(ex1));
// it will split at spaces and return an array of ["I","like","apples!"]
// Example 2: "I really like really red apples!".split("really")
// it will split at the word "really" and return an array of ["I "," like ","red apples!"]
		String[] ex2 = "I really like really red apples!".split("really");
		System.out.println(Arrays.toString(ex2));
//play around with String.split!
//What happens if you "I reallyreally likeapples".split("really") ?
		
		
		String[] ex3 = "I reallyreally likeapples!".split("really");
		System.out.println(Arrays.toString(ex3));
		
		System.out.println(samich("bread cheese"));
		System.out.println(samich("applesbreadmayobread"));
		
		System.out.println(samich("hambreadmayobaconbreadavocadobreadbreadhambreadcheese"));
		
		
	}
//Your task Part 1:
/*Write a method that take in a string like
* "applespineapplesbreadlettucetomatobaconmayohambreadcheese"
* describing a sandwich.
* Use String.split to split up the sandwich by the word "bread" and return what's in the middle of
* the sandwich and ignores what's on the outside
* What if it's a fancy sandwich with multiple pieces of bread?
*/
		public static String samich(String menu) {
			String carb = "bread";
			//int idxEnd = menu.indexOf();
			String[] fill = menu.split(carb);
			
			//finds last occurence of "bread" as an index
			int end = 0;
			//while(end<0) {
			for(int i = fill.length-1; end<0; i--) { 
				if (fill[i].equals(carb)) {
					end = i;
					}
				}
			//}
			
			
			
			//test
			System.out.println("test[1]: " + Arrays.toString(fill));
			System.out.println("	[1]=" + fill[1]);
			
			System.out.println("fill array printed" + Arrays.toString(fill));
			if(fill.length==1) {
				return "not a sandwich";
			}
			if(fill.length>0) {
				
				
				if(menu.split("bread").length > menu.length()-(2*carb.length())) {
					System.out.println(fill[1]);
				}
				else if(fill.length<2){
					System.out.println("not a sandwich");
				}
				else if(fill.length>2){
					for(int i = 0;i<fill.length;i++) {
						
						if(i==0 && Arrays.toString(fill).indexOf(",")<Arrays.toString(fill).indexOf(fill[1])) {
							System.out.print("");
						}
						
						
						
						
				//stopping at last "bread" first attempt
						/*else if(Arrays.toString(fill).indexOf){//figure out where last bread is and skip printing all i values after
							System.out.print("");
						}
						else if(fill[Arrays.length(fill)].!equals("bread"){
							
						}
							else {
							System.out.print("&" + fill[i]);
						}
						*/
						
				//second attempt
						
						
						
					} 
				}else {
					System.out.println(fill[1]);
				}
			}
			
			
			
			
			return "";
		}
		
		
		
		
		
//Your task pt 2:

/*Write a method that take in a string like

* "apples pineapples bread lettuce tomato bacon mayo ham bread cheese"

* describing a sandwich

* use String.split to split up the sandwich at the spaces, " ", and return what's in the middle of

* the sandwich and ignores what's on the outside.

*The output for the example above should be lettucetomatobaconmayoham

* You should call the method from part one in order to increase your reuse of code and reduce

*the complexity of part 2.

*/
	}

		

		 



/*
 * if(indexof "bread" 
 * for(int i:  ){
 * 		String test = fill[i]
 * 		if (test.equals("bread"
 * 			for (j = i; j++)
 * 			if(fill[j].equals("bread")
 * 				System.out.print("fill[i]");
 * 			else{
 * 			}
 * 	}
 * if (
 */


